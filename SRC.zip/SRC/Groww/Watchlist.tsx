import { motion } from "framer-motion";

type WatchItem = {
  symbol: string;
  exchange: "NSE" | "BSE";
  price: number;
  change: number;
  changePct: number;
};

const WATCHLIST: WatchItem[] = [
  { symbol: "ICICIBANK", exchange: "NSE", price: 1326.2, change: 0, changePct: 0 },
  { symbol: "NIVABUPA", exchange: "NSE", price: 77.07, change: 0, changePct: 0 },
  { symbol: "AXISBANK", exchange: "BSE", price: 1366.1, change: 0, changePct: 0 },
  { symbol: "MAXHEALTH", exchange: "NSE", price: 999.4, change: 0, changePct: 0 },
  { symbol: "MUTHOOTFIN", exchange: "NSE", price: 3493.5, change: 0, changePct: 0 },
  { symbol: "TRANSRAIL", exchange: "BSE", price: 575.95, change: 0, changePct: 0 },
];

function fmt(n: number) {
  return n.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function Watchlist() {
  return (
    <section className="px-5 pb-6 pt-2">
      <ul className="divide-y divide-hairline">
        {WATCHLIST.map((w, i) => {
          const positive = w.change >= 0;
          return (
            <motion.li
              key={w.symbol}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.03 + i * 0.04, ease: [0.16, 1, 0.3, 1] }}
              className="flex cursor-pointer items-start justify-between gap-4 py-4 transition-colors hover:bg-secondary/40"
            >
              <div className="min-w-0">
                <p className="text-[15px] font-medium tracking-tight text-foreground">
                  {w.symbol}
                </p>
                <p className="mt-1 font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
                  {w.exchange}
                </p>
              </div>
              <div className="text-right">
                <p className="font-mono text-[15px] font-medium tnum text-foreground">
                  {fmt(w.price)}
                </p>
                <p
                  className={`font-mono text-xs tnum ${
                    w.change === 0 ? "text-muted-foreground" : positive ? "text-gain" : "text-loss"
                  }`}
                >
                  {positive && w.change !== 0 ? "+" : ""}
                  {fmt(w.change)} ({positive && w.change !== 0 ? "+" : ""}
                  {w.changePct.toFixed(2)}%)
                </p>
              </div>
            </motion.li>
          );
        })}
      </ul>
    </section>
  );
}