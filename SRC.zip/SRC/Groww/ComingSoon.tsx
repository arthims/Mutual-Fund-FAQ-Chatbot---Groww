import { motion } from "framer-motion";
import { Landmark } from "lucide-react";

export function ComingSoon({ title = "Loans" }: { title?: string }) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 12, filter: "blur(4px)" }}
      animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="flex h-full flex-col items-center justify-center px-8 py-20 text-center"
    >
      <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl border border-hairline bg-secondary/50">
        <Landmark className="h-6 w-6 text-muted-foreground" strokeWidth={1.5} />
      </div>
      <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
        {title}
      </p>
      <h2 className="mt-2 text-2xl font-semibold tracking-tight text-foreground">
        Coming soon
      </h2>
      <p className="mt-3 max-w-[260px] text-sm leading-relaxed text-muted-foreground">
        We're building a calmer way to borrow. Check back shortly.
      </p>
    </motion.section>
  );
}