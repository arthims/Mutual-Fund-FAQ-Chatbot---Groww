import { motion } from "framer-motion";
import { ArrowUpDown, Percent } from "lucide-react";

type Holding = {
  name: string;
  tags: string[];
  current: number;
  pct: number;
  invested: number;
};

const HOLDINGS: Holding[] = [
  { name: "HDFC Mid Cap Opportunities Fund Growth", tags: ["Regular", "External"], current: 53095, pct: 69.9, invested: 31250 },
  { name: "ICICI Prudential Bluechip Fund Growth", tags: ["Regular", "External"], current: 89220, pct: 67.6, invested: 53234 },
  { name: "Franklin India Prima Fund Growth", tags: ["Regular", "External"], current: 58214, pct: 42.1, invested: 40970 },
  { name: "Parag Parikh Flexi Cap Fund Direct", tags: ["Direct", "Groww"], current: 124880, pct: 31.2, invested: 95180 },
  { name: "Axis Small Cap Fund Growth", tags: ["Regular", "External"], current: 41320, pct: -3.4, invested: 42775 },
  { name: "Quant Active Fund Direct Growth", tags: ["Direct", "Groww"], current: 78460, pct: 22.8, invested: 63890 },
];

function fmtINR(n: number) {
  return n.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

export function HoldingsList() {
  return (
    <section className="px-5 pb-6 pt-6">
      {/* Sort header */}
      <div className="flex items-center justify-between pb-3">
        <button className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <span>Sort</span>
          <ArrowUpDown className="h-3.5 w-3.5" strokeWidth={1.75} />
        </button>
        <button className="inline-flex items-center gap-1.5 text-sm font-medium text-gain">
          <Percent className="h-3.5 w-3.5" strokeWidth={2} />
          Returns (%)
        </button>
      </div>

      <ul className="divide-y divide-hairline">
        {HOLDINGS.map((h, i) => {
          const positive = h.pct >= 0;
          return (
            <motion.li
              key={h.name}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.05 + i * 0.04, ease: [0.16, 1, 0.3, 1] }}
              className="cursor-pointer py-4 transition-colors hover:bg-secondary/40"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="min-w-0 flex-1">
                  <p className="text-[15px] font-medium leading-snug text-foreground">
                    {h.name}
                  </p>
                  <div className="mt-2 flex flex-wrap items-center gap-1.5">
                    {h.tags.map((t) => (
                      <span
                        key={t}
                        className="rounded-md bg-secondary px-1.5 py-0.5 font-mono text-[10px] uppercase tracking-wider text-muted-foreground"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="text-right">
                  <p className={`font-mono text-[15px] font-medium tnum ${positive ? "text-gain" : "text-loss"}`}>
                    {positive ? "+" : "-"}₹{fmtINR(Math.abs(h.current - h.invested))}
                  </p>
                  <p className={`font-mono text-xs tnum ${positive ? "text-gain" : "text-loss"}`}>
                    ({positive ? "+" : ""}{h.pct.toFixed(1)}%)
                  </p>
                </div>
              </div>
            </motion.li>
          );
        })}
      </ul>
    </section>
  );
}