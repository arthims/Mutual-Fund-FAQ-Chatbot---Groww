import { Search, LogOut, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const TABS = ["Dashboard", "Orders", "SIPs", "Watchlist"];

interface Props {
  activeTab: string;
  onTabChange: (t: string) => void;
}

export function PortfolioHeader({ activeTab, onTabChange }: Props) {
  const { toast } = useToast();

  return (
    <div className="border-b border-hairline bg-card">
      {/* Search row */}
      <div className="flex items-center gap-3 px-5 pt-5 pb-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              aria-label="Open profile menu"
              className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-emerald-700 text-white outline-none ring-offset-2 ring-offset-card transition-shadow focus-visible:ring-2 focus-visible:ring-foreground/40 active:scale-95"
            >
              <User className="h-4 w-4" strokeWidth={2.25} />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-56">
            <DropdownMenuLabel className="flex flex-col gap-0.5 py-2">
              <span className="text-sm font-semibold">Investor</span>
              <span className="text-[11px] font-normal text-muted-foreground">
                investor@groww.app
              </span>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              className="cursor-pointer text-loss focus:text-loss"
              onSelect={() =>
                toast({
                  title: "Logged out",
                  description: "You've been signed out of this demo session.",
                })
              }
            >
              <LogOut className="mr-2 h-4 w-4" strokeWidth={2} />
              Log out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        <div className="flex h-10 flex-1 items-center gap-2 rounded-full border border-hairline bg-secondary/60 px-4">
          <Search className="h-4 w-4 text-muted-foreground" strokeWidth={1.75} />
          <span className="text-sm text-muted-foreground">Search Groww</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="no-scrollbar flex gap-1 overflow-x-auto px-3 pb-2">
        {TABS.map((tab) => {
          const active = tab === activeTab;
          return (
            <button
              key={tab}
              onClick={() => onTabChange(tab)}
              className={`relative whitespace-nowrap rounded-full px-4 py-1.5 text-sm transition-colors ${
                active
                  ? "bg-foreground text-background"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab}
            </button>
          );
        })}
      </div>
    </div>
  );
}