import { motion } from "framer-motion";
import { ArrowDownLeft, ArrowUpRight, Filter } from "lucide-react";

type OrderStatus = "Executed" | "Pending" | "Cancelled" | "Failed";
type OrderSide = "BUY" | "SELL";

type Order = {
  id: string;
  instrument: string;
  type: "Stock" | "Mutual Fund";
  side: OrderSide;
  qty: number;
  price: number;
  amount: number;
  status: OrderStatus;
  placedAt: string; // human readable
};

const ORDERS: Order[] = [
  { id: "GR-48201", instrument: "Reliance Industries", type: "Stock", side: "BUY", qty: 12, price: 2841.5, amount: 34098, status: "Executed", placedAt: "Today, 10:14" },
  { id: "GR-48199", instrument: "Parag Parikh Flexi Cap — Direct", type: "Mutual Fund", side: "BUY", qty: 1, price: 5000, amount: 5000, status: "Pending", placedAt: "Today, 09:31" },
  { id: "GR-48180", instrument: "HDFC Bank", type: "Stock", side: "SELL", qty: 25, price: 1612.2, amount: 40305, status: "Executed", placedAt: "Yesterday, 15:42" },
  { id: "GR-48177", instrument: "Tata Motors", type: "Stock", side: "BUY", qty: 40, price: 974.85, amount: 38994, status: "Cancelled", placedAt: "Yesterday, 12:08" },
  { id: "GR-48164", instrument: "Axis Small Cap — Growth", type: "Mutual Fund", side: "SELL", qty: 1, price: 12500, amount: 12500, status: "Executed", placedAt: "23 Apr, 14:55" },
  { id: "GR-48150", instrument: "Infosys", type: "Stock", side: "BUY", qty: 8, price: 1487.6, amount: 11901, status: "Failed", placedAt: "23 Apr, 11:20" },
  { id: "GR-48131", instrument: "ICICI Prudential Bluechip — Reg.", type: "Mutual Fund", side: "BUY", qty: 1, price: 2500, amount: 2500, status: "Executed", placedAt: "22 Apr, 09:30" },
  { id: "GR-48118", instrument: "Bajaj Finance", type: "Stock", side: "SELL", qty: 4, price: 7218.0, amount: 28872, status: "Executed", placedAt: "21 Apr, 15:11" },
];

const STATUS_STYLES: Record<OrderStatus, string> = {
  Executed: "bg-gain-soft text-gain",
  Pending: "bg-bolt-soft text-bolt",
  Cancelled: "bg-secondary text-muted-foreground",
  Failed: "bg-loss-soft text-loss",
};

const FILTERS = ["All", "Executed", "Pending", "Cancelled", "Failed"] as const;

function fmtINR(n: number) {
  return n.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

export function OrdersList() {
  return (
    <section className="px-5 pb-6 pt-5">
      {/* Heading */}
      <div className="flex items-center justify-between pb-3">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.08em] text-muted-foreground">
            Recent activity
          </p>
          <h2 className="mt-0.5 text-[17px] font-semibold tracking-tight text-foreground">
            Orders
          </h2>
        </div>
        <button
          aria-label="Filter orders"
          className="inline-flex items-center gap-1.5 rounded-full border border-hairline px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground"
        >
          <Filter className="h-3.5 w-3.5" strokeWidth={1.75} />
          Filter
        </button>
      </div>

      {/* Filter chips */}
      <div className="no-scrollbar -mx-5 flex gap-1.5 overflow-x-auto px-5 pb-4">
        {FILTERS.map((f, i) => (
          <button
            key={f}
            className={`whitespace-nowrap rounded-full px-3 py-1 text-xs transition-colors ${
              i === 0
                ? "bg-foreground text-background"
                : "bg-secondary/60 text-muted-foreground hover:text-foreground"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {/* Orders list */}
      <ul className="divide-y divide-hairline overflow-hidden rounded-2xl border border-hairline bg-card">
        {ORDERS.map((o, i) => {
          const isBuy = o.side === "BUY";
          const SideIcon = isBuy ? ArrowDownLeft : ArrowUpRight;
          return (
            <motion.li
              key={o.id}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.04 * i, ease: [0.16, 1, 0.3, 1] }}
              className="cursor-pointer px-4 py-3.5 transition-colors hover:bg-secondary/40"
            >
              <div className="flex items-start gap-3">
                <div
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${
                    isBuy ? "bg-gain-soft text-gain" : "bg-loss-soft text-loss"
                  }`}
                >
                  <SideIcon className="h-4 w-4" strokeWidth={2} />
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-start justify-between gap-3">
                    <p className="truncate text-[14px] font-medium text-foreground">
                      {o.instrument}
                    </p>
                    <p className="font-mono text-[14px] font-medium tnum text-foreground">
                      ₹{fmtINR(o.amount)}
                    </p>
                  </div>

                  <div className="mt-1 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                      <span
                        className={`font-mono font-medium ${
                          isBuy ? "text-gain" : "text-loss"
                        }`}
                      >
                        {o.side}
                      </span>
                      <span>·</span>
                      <span className="font-mono tnum">
                        {o.qty} {o.type === "Stock" ? "qty" : "unit"} @ ₹
                        {o.price.toLocaleString("en-IN", { maximumFractionDigits: 2 })}
                      </span>
                    </div>
                    <span
                      className={`rounded-full px-2 py-0.5 font-mono text-[10px] uppercase tracking-wider ${STATUS_STYLES[o.status]}`}
                    >
                      {o.status}
                    </span>
                  </div>

                  <div className="mt-1.5 flex items-center justify-between text-[11px] text-muted-foreground">
                    <span>{o.placedAt}</span>
                    <span className="font-mono">{o.id}</span>
                  </div>
                </div>
              </div>
            </motion.li>
          );
        })}
      </ul>

      <p className="mt-4 text-center text-[11px] text-muted-foreground">
        Showing last 8 orders · Settlement T+1
      </p>
    </section>
  );
}