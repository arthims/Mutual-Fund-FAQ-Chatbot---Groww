import { TrendingUp, PieChart, Landmark } from "lucide-react";

const ITEMS = [
  { key: "stocks", label: "Stocks", icon: TrendingUp },
  { key: "mutual", label: "Mutual Funds", icon: PieChart },
  { key: "loans", label: "Loans", icon: Landmark },
];

interface BottomNavProps {
  active?: string;
  onChange?: (key: string) => void;
}

export function BottomNav({ active = "mutual", onChange }: BottomNavProps) {
  return (
    <nav className="border-t border-hairline bg-card">
      <ul className="grid grid-cols-3">
        {ITEMS.map(({ key, label, icon: Icon }) => {
          const isActive = key === active;
          return (
            <li key={key}>
              <button
                onClick={() => onChange?.(key)}
                className={`flex w-full flex-col items-center gap-1 py-3 transition-colors ${
                  isActive ? "text-gain" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="h-5 w-5" strokeWidth={isActive ? 2 : 1.5} />
                <span className={`text-[11px] ${isActive ? "font-medium" : ""}`}>{label}</span>
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}