import { motion } from "framer-motion";
import { ArrowUpRight, RefreshCw } from "lucide-react";

function fmtINR(n: number) {
  return n.toLocaleString("en-IN", { maximumFractionDigits: 0 });
}

export function SummaryCard() {
  const current = 1435690;
  const invested = 1129783;
  const totalReturn = current - invested;
  const totalPct = (totalReturn / invested) * 100;
  const oneDay = -9813.36;
  const oneDayPct = -0.68;
  const xirr = 18.4;

  return (
    <motion.section
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      className="px-5 pt-5"
    >
      <div className="flex items-center justify-between pb-3">
        <p className="font-mono text-[11px] uppercase tracking-[0.08em] text-muted-foreground">
          Portfolio · Holdings (22)
        </p>
        <button
          aria-label="Refresh"
          className="flex items-center gap-1 rounded-full px-2 py-1 text-[11px] text-muted-foreground hover:bg-secondary/60"
        >
          <RefreshCw className="h-3 w-3" strokeWidth={2} />
          9:00
        </button>
      </div>

      <div className="rounded-2xl border border-hairline bg-card p-5">
        {/* Top row: Current / Total returns */}
        <div className="grid grid-cols-2 gap-4 pb-5">
          <div>
            <p className="text-xs text-muted-foreground">Current</p>
            <p className="font-mono text-[26px] font-medium tracking-tight tnum text-foreground">
              ₹{fmtINR(current)}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Total returns</p>
            <p className="font-mono text-[20px] font-medium tnum text-gain">
              +₹{fmtINR(totalReturn)}
            </p>
            <p className="font-mono text-xs tnum text-gain">
              +{totalPct.toFixed(2)}%
            </p>
          </div>
        </div>

        <div className="h-px bg-hairline" />

        {/* Bottom row: Invested / 1D returns */}
        <div className="grid grid-cols-2 gap-4 pt-4">
          <div>
            <p className="text-xs text-muted-foreground">Invested</p>
            <p className="font-mono text-[18px] font-medium tnum text-foreground">
              ₹{fmtINR(invested)}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">1D returns</p>
            <p className="font-mono text-[18px] font-medium tnum text-loss">
              -₹{Math.abs(oneDay).toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
            <p className="font-mono text-xs tnum text-loss">{oneDayPct}%</p>
          </div>
        </div>

        {/* XIRR + analysis */}
        <div className="mt-5 flex items-center justify-between border-t border-hairline pt-4">
          <div className="flex items-center gap-2">
            <span className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
              XIRR
            </span>
            <span className="rounded-full bg-gain-soft px-2.5 py-0.5 font-mono text-xs font-medium tnum text-gain">
              {xirr}%
            </span>
          </div>
          <button className="group inline-flex items-center gap-1 text-sm font-medium text-foreground">
            <span className="border-b border-foreground/30 pb-px transition-colors group-hover:border-foreground">
              Portfolio analysis
            </span>
            <ArrowUpRight className="h-3.5 w-3.5" strokeWidth={2} />
          </button>
        </div>
      </div>
    </motion.section>
  );
}