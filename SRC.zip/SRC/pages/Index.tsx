import { useEffect, useState } from "react";
import { PortfolioHeader } from "@/components/groww/PortfolioHeader";
import { SummaryCard } from "@/components/groww/SummaryCard";
import { HoldingsList } from "@/components/groww/HoldingsList";
import { OrdersList } from "@/components/groww/OrdersList";
import { Watchlist } from "@/components/groww/Watchlist";
import { BottomNav } from "@/components/groww/BottomNav";
import { ChatBolt } from "@/components/groww/ChatBolt";
import { ComingSoon } from "@/components/groww/ComingSoon";

const Index = () => {
  const [tab, setTab] = useState("Dashboard");
  const [bottom, setBottom] = useState("mutual");

  useEffect(() => {
    document.title = "Groww — Portfolio Dashboard";
    const meta =
      document.querySelector('meta[name="description"]') ||
      Object.assign(document.createElement("meta"), { name: "description" });
    meta.setAttribute(
      "content",
      "Track mutual funds, stocks, SIPs, and XIRR in one calm dashboard. Ask ChatBolt for portfolio-specific insights."
    );
    if (!meta.parentNode) document.head.appendChild(meta);
  }, []);

  return (
    <main className="min-h-screen bg-background">
      {/* Desktop framing label */}
      <div className="mx-auto hidden max-w-md px-6 pb-3 pt-10 lg:block">
        <p className="font-mono text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
          Groww · Wealth, clarified
        </p>
        <h1 className="mt-1 text-2xl font-semibold tracking-tight text-foreground">
          Your portfolio, in plain numbers.
        </h1>
      </div>

      {/* App container — mobile-first, framed on desktop */}
      <div className="relative mx-auto flex min-h-screen max-w-md flex-col overflow-hidden border-hairline bg-card lg:my-6 lg:min-h-0 lg:h-[820px] lg:rounded-[28px] lg:border lg:shadow-[0_24px_60px_-20px_rgb(0_0_0/0.18)]">
        <PortfolioHeader activeTab={tab} onTabChange={setTab} />

        <div className="flex-1 overflow-y-auto">
          {bottom === "loans" ? (
            <ComingSoon title="Loans" />
          ) : tab === "Orders" ? (
            <OrdersList />
          ) : tab === "Watchlist" ? (
            <Watchlist />
          ) : (
            <>
              <SummaryCard />
              <HoldingsList />
            </>
          )}
        </div>

        <BottomNav active={bottom} onChange={setBottom} />
        <ChatBolt />
      </div>
    </main>
  );
};

export default Index;
